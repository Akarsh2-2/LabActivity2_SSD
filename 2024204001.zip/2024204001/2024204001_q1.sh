#!/bin/bash
filename="$1"

find / -type f -name "*$file*" 2>/dev/null | while read -r file; do  
   echo "Your File is found: $file"

head -n 4 "$file"
   echo
done

