#!/bin/bash
export X=7
export Y=3
sum=$((X + Y))
echo "The sum of $X and $Y is $sum."
