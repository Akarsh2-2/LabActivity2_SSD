Question-1
In this question, First we give argument file name which is 
john_doe_assignment.txt. Then code will search the file from the root and 
when ever it will find the same file, it will display it on screen "FILE 
HAS FOUND". AND IT will print its starting four lines.

Question-2a
First we checked if a command-line argument is provided
then we initialize the first two terms
then give logic to print the Fibonacci sequence.

Question-2b
In this question, First i exported two variables X & Y. then Simply added 
using SUM and print in a string using echo.
