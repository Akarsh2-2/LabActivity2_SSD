#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 <number_of_terms>"
    exit 1
fi
n=$1
echo "Number of terms: $n"

a=0
b=1

for (( i=0; i<n; i++ )); do
    echo -n "$a "
    fn=$((a + b))
    a=$b
    b=$fn
done

echo
